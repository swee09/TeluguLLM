from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import torch
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    BitsAndBytesConfig,
    AutoProcessor,
    AutoModelForVision2Seq,
    pipeline,
    AutoModelForAudioClassification,
)
from peft import PeftModel  # In case you use PEFT adapters
import base64
from PIL import Image  # For image processing
import io
import os
import tempfile
import soundfile as sf

app = Flask(__name__, static_folder='static')
CORS(app)

# --- Serve demo.html at root ---
@app.route('/demo', methods=['GET'])
def serve_demo():
    return send_from_directory(app.static_folder, 'demo.html')

@app.route('/', methods=['GET'])
def home():
    return send_from_directory(app.static_folder, 'demo.html')

# --- Configuration ---
TELUGU_LLM_MODEL_ID = "Telugu-LLM-Labs/Indic-gemma-7b-finetuned-sft-Navarasa-2.0"
OCR_MODEL_ID = "ChatDOC/OCRFlux-3B"
AUDIO_CLASSIFICATION_MODEL_ID = "facebook/wav2vec2-base-960h"   # <-- Specify your audio model here

# --- Quantization Configuration ---
print("Configuring BitsAndBytes for quantization...")
quantization_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16  # Use bfloat16 if your GPU supports
)
print("BitsAndBytes configuration complete.")

# --- Telugu LLM Loading ---
print(f"Loading tokenizer for Telugu LLM: {TELUGU_LLM_MODEL_ID}...")
telugu_tokenizer = AutoTokenizer.from_pretrained(TELUGU_LLM_MODEL_ID)
if telugu_tokenizer.pad_token is None:
    telugu_tokenizer.pad_token = telugu_tokenizer.eos_token
print("Telugu LLM Tokenizer loaded successfully.")

print(f"Loading Telugu LLM: {TELUGU_LLM_MODEL_ID} with quantization...")
try:
    telugu_model = AutoModelForCausalLM.from_pretrained(
        TELUGU_LLM_MODEL_ID,
        quantization_config=quantization_config,
        device_map="auto",
        torch_dtype=torch.bfloat16
    )
    print("Telugu LLM loaded successfully with quantization.")
except Exception as e:
    print(f"Error loading Telugu LLM with quantization: {e}")
    print("Attempting to load Telugu LLM without quantization (might require more VRAM)...")
    telugu_model = AutoModelForCausalLM.from_pretrained(
        TELUGU_LLM_MODEL_ID,
        device_map="auto",
        torch_dtype=torch.float16
    )
    print("Telugu LLM loaded successfully without quantization.")
telugu_model.eval()

# --- OCR Model Loading ---
print(f"Loading processor for OCR model: {OCR_MODEL_ID}...")
ocr_processor = AutoProcessor.from_pretrained(OCR_MODEL_ID)
print("OCR Processor loaded successfully.")

print(f"Loading OCR model: {OCR_MODEL_ID} with quantization...")
try:
    ocr_model = AutoModelForVision2Seq.from_pretrained(
        OCR_MODEL_ID,
        quantization_config=quantization_config,
        device_map="auto",
        torch_dtype=torch.bfloat16
    )
    print("OCR model loaded successfully with quantization.")
except Exception as e:
    print(f"Error loading OCR model with quantization: {e}")
    print("Attempting to load OCR model without quantization...")
    ocr_model = AutoModelForVision2Seq.from_pretrained(
        OCR_MODEL_ID,
        device_map="auto",
        torch_dtype=torch.float16
    )
    print("OCR model loaded successfully without quantization.")
ocr_model.eval()

# --- Audio Classification Model Loading ---
print(f"Loading audio classification pipeline for: {AUDIO_CLASSIFICATION_MODEL_ID}...")
audio_classifier_pipeline = None
try:
    audio_classifier_pipeline = pipeline(
        "audio-classification",
        model=AUDIO_CLASSIFICATION_MODEL_ID,
        trust_remote_code=True,
        torch_dtype="auto",
        device="cuda" if torch.cuda.is_available() else "cpu"
    )
    print("Audio classification pipeline loaded successfully.")
except Exception as e:
    print(f"Error loading audio classification pipeline: {e}")
    print(f"Attempting to load audio classification model directly: {AUDIO_CLASSIFICATION_MODEL_ID}...")
    try:
        audio_model_direct = AutoModelForAudioClassification.from_pretrained(
            AUDIO_CLASSIFICATION_MODEL_ID,
            trust_remote_code=True,
            torch_dtype="auto",
            device_map="auto"
        )
        print("Audio classification model loaded directly (pipeline failed to initialize).")
    except Exception as e_direct:
        print(f"Failed to load audio classification model directly either: {e_direct}")

# --- Telugu LLM Inference Function ---
def generate_telugu_response_backend(user_input: str, student_class: int = None, mode: str = "first_language") -> str:
    print(f"Received input for Telugu LLM: {user_input}")
    if mode == "second_language":
        prompt = f"ఈ ప్రశ్న {student_class}వ తరగతి విద్యార్థికి రెండవ భాష (తెలుగు) పాఠ్యపుస్తకానికి సంబంధించింది. దయచేసి దీనిని సులభమైన తెలుగులో వివరించండి:\n\n{user_input}\n\n### Response:"
    else:
        prompt = f"ఈ ప్రశ్న {student_class}వ తరగతి విద్యార్థికి మొదటి భాష (తెలుగు) పాఠ్యపుస్తకానికి సంబంధించినది. వివరంగా సమాధానం తెలుగులో ఇవ్వండి:\n\n{user_input}\n\n### Response:"
    input_ids = telugu_tokenizer.encode(prompt, return_tensors="pt").to(telugu_model.device)
    outputs = telugu_model.generate(
        input_ids,
        max_new_tokens=250,
        num_beams=5,
        no_repeat_ngram_size=2,
        early_stopping=True,
        do_sample=True,
        temperature=0.7,
        top_k=50,
        top_p=0.9,
        pad_token_id=telugu_tokenizer.pad_token_id,
        eos_token_id=telugu_tokenizer.eos_token_id
    )
    generated_text = telugu_tokenizer.decode(outputs[0], skip_special_tokens=True)
    response_start_marker = "### Response:"
    if response_start_marker in generated_text:
        response_only = generated_text.split(response_start_marker, 1)[1].strip()
    else:
        response_only = generated_text.strip()
    response_only = response_only.replace("### Instruction:", "").replace("### Response:", "").strip()
    print(f"Generated response from Telugu LLM: {response_only}")
    return response_only

# --- OCR Inference Function ---
def process_image_with_ocr(image_base64: str) -> str:
    try:
        image_bytes = base64.b64decode(image_base64)
        image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    except Exception as e:
        print(f"Error decoding image or opening with PIL: {e}")
        raise ValueError("Invalid image format or base64 string provided.")
    print("Image decoded and ready for OCR processing.")
    inputs = ocr_processor(images=image, return_tensors="pt").to(ocr_model.device)
    generated_ids = ocr_model.generate(**inputs, max_new_tokens=500)
    extracted_text = ocr_processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
    print(f"Extracted text from image: {extracted_text}")
    return extracted_text

# --- Audio Classification Inference Function ---
def classify_audio_backend(audio_base64: str) -> list:
    if audio_classifier_pipeline is None:
        raise RuntimeError("Audio classification model not loaded successfully. Please check server logs.")
    temp_audio_path = None
    try:
        audio_bytes = base64.b64decode(audio_base64)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_audio_file:
            temp_audio_file.write(audio_bytes)
            temp_audio_path = temp_audio_file.name
        print(f"Audio saved to temporary file: {temp_audio_path}")
        classification_results = audio_classifier_pipeline(temp_audio_path)
        print(f"Audio classification results: {classification_results}")
        return classification_results
    except Exception as e:
        print(f"Error during audio classification: {e}")
        raise ValueError(f"Failed to process audio: {e}")
    finally:
        if temp_audio_path and os.path.exists(temp_audio_path):
            os.remove(temp_audio_path)
            print(f"Temporary audio file removed: {temp_audio_path}")

# --- API Endpoint for Telugu LLM ---
@app.route('/generate', methods=['POST'])
def generate_text():
    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400
    data = request.get_json()
    user_input = data.get('text')
    student_class = data.get('class', 8)
    mode = data.get('mode', 'first_language')
    if not user_input:
        return jsonify({"error": "Missing 'text' in request body"}), 400
    try:
        llm_response = generate_telugu_response_backend(user_input, student_class, mode)
        return jsonify({"response": llm_response})
    except Exception as e:
        print(f"Error during Telugu LLM generation: {e}")
        return jsonify({"error": "Internal server error during text generation"}), 500

# --- API Endpoint for OCR Model ---
@app.route('/ocr_generate', methods=['POST'])
def ocr_generate_text():
    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400
    data = request.get_json()
    image_base64 = data.get('image_base64')
    if not image_base64:
        return jsonify({"error": "Missing 'image_base64' in request body"}), 400
    try:
        extracted_text = process_image_with_ocr(image_base64)
        return jsonify({"extracted_text": extracted_text})
    except ValueError as ve:
        return jsonify({"error": str(ve)}), 400
    except Exception as e:
        print(f"Error during OCR generation: {e}")
        return jsonify({"error": "Internal server error during OCR processing"}), 500

# --- API Endpoint for Audio Classification ---
@app.route('/classify_audio', methods=['POST'])
def classify_audio_endpoint():
    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400
    data = request.get_json()
    audio_base64 = data.get('audio_base64')
    if not audio_base64:
        return jsonify({"error": "Missing 'audio_base64' in request body"}), 400
    try:
        classification_results = classify_audio_backend(audio_base64)
        return jsonify({"classification_results": classification_results})
    except ValueError as ve:
        return jsonify({"error": str(ve)}), 400
    except RuntimeError as re:
        return jsonify({"error": str(re)}), 503
    except Exception as e:
        print(f"Error during audio classification endpoint call: {e}")
        return jsonify({"error": "Internal server error during audio classification"}), 500

# --- Run the Flask App ---
if __name__ == '__main__':
    print("Starting Flask application...")
    app.run(host='0.0.0.0', port=5000, debug=False)

