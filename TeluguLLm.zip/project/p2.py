from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS  # To handle Cross-Origin Resource Sharing
import torch
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    BitsAndBytesConfig,
    AutoProcessor,
    AutoModelForVision2Seq,
)
# from peft import PeftModel  # Only needed if you're loading fine-tuned PEFT adapters
import base64
from PIL import Image  # For image processing
import io  # For handling image bytes
import os

app = Flask(__name__, static_folder='static')
CORS(app)  # Enable CORS for all routes, allowing frontend to access it


# --- Serve demo.html at root ---
@app.route('/demo', methods=['GET'])
def serve_demo():
    return send_from_directory(app.static_folder, 'demo.html')


@app.route('/', methods=['GET'])
def home():
    return send_from_directory(app.static_folder, 'demo.html')


# --- Configuration ---
# Define the pre-trained model IDs from Hugging Face Hub.
TELUGU_LLM_MODEL_ID = "Telugu-LLM-Labs/Indic-gemma-7b-finetuned-sft-Navarasa-2.0"
OCR_MODEL_ID = "ChatDOC/OCRFlux-3B"
# AUDIO_CLASSIFICATION_MODEL_ID = "YourAudioModelIDHere"  # Uncomment and set if using audio classification


# --- Quantization Configuration ---
print("Configuring BitsAndBytes for quantization...")
quantization_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16,  # Use bfloat16 if your GPU supports it
)
print("BitsAndBytes configuration complete.")


# --- Telugu LLM Loading (Original Model) ---
print(f"Loading tokenizer for Telugu LLM: {TELUGU_LLM_MODEL_ID}...")
telugu_tokenizer = AutoTokenizer.from_pretrained(TELUGU_LLM_MODEL_ID)
if telugu_tokenizer.pad_token is None:
    telugu_tokenizer.pad_token = telugu_tokenizer.eos_token
print("Telugu LLM Tokenizer loaded successfully.")


print(f"Loading Telugu LLM: {TELUGU_LLM_MODEL_ID} with quantization...")
try:
    telugu_model = AutoModelForCausalLM.from_pretrained(
        TELUGU_LLM_MODEL_ID,
        quantization_config=quantization_config,
        device_map="auto",
        torch_dtype=torch.bfloat16,  # Use bfloat16 if your GPU supports it
    )
    print("Telugu LLM loaded successfully with quantization.")
except Exception as e:
    print(f"Error loading Telugu LLM with quantization: {e}")
    print("Attempting to load Telugu LLM without quantization (might require more VRAM)...")
    telugu_model = AutoModelForCausalLM.from_pretrained(
        TELUGU_LLM_MODEL_ID,
        device_map="auto",
        torch_dtype=torch.float16,  # Fallback to float16 if bfloat16 causes issues or is not supported
    )
    print("Telugu LLM loaded successfully without quantization.")


telugu_model.eval()  # Set model to evaluation mode


# --- OCR Model Loading (New Model) ---
print(f"Loading processor for OCR model: {OCR_MODEL_ID}...")
ocr_processor = AutoProcessor.from_pretrained(OCR_MODEL_ID)
print("OCR Processor loaded successfully.")


print(f"Loading OCR model: {OCR_MODEL_ID} with quantization...")
try:
    ocr_model = AutoModelForVision2Seq.from_pretrained(
        OCR_MODEL_ID,
        quantization_config=quantization_config,  # Apply quantization if desired/supported
        device_map="auto",
        torch_dtype=torch.bfloat16,  # Use bfloat16 if GPU supports it
    )
    print("OCR model loaded successfully with quantization.")
except Exception as e:
    print(f"Error loading OCR model with quantization: {e}")
    print("Attempting to load OCR model without quantization...")
    ocr_model = AutoModelForVision2Seq.from_pretrained(
        OCR_MODEL_ID,
        device_map="auto",
        torch_dtype=torch.float16,  # Fallback
    )
    print("OCR model loaded successfully without quantization.")


ocr_model.eval()  # Set model to evaluation mode


# --- Telugu LLM Inference Function (Backend Logic) ---
def generate_telugu_response_backend(user_input: str) -> str:
    """
    Generates a Telugu response from the LLM based on user input.
    This function is called by the API endpoint.
    """
    prompt = f"### Instruction:\n{user_input}\n\n### Response:"
    print(f"Received input for Telugu LLM: {user_input}")

    # Encode the prompt and move to the model's device (e.g., GPU)
    input_ids = telugu_tokenizer.encode(prompt, return_tensors="pt").to(telugu_model.device)

    # Generate text using the Telugu LLM
    outputs = telugu_model.generate(
        input_ids,
        max_new_tokens=250,
        num_beams=5,
        no_repeat_ngram_size=2,
        early_stopping=True,
        do_sample=True,
        temperature=0.7,
        top_k=50,
        top_p=0.9,
        pad_token_id=telugu_tokenizer.pad_token_id,
        eos_token_id=telugu_tokenizer.eos_token_id,
    )

    # Decode the generated tokens back to a string
    generated_text = telugu_tokenizer.decode(outputs[0], skip_special_tokens=True)

    # Extract only the response part from the generated text
    response_start_marker = "### Response:"
    if response_start_marker in generated_text:
        response_only = generated_text.split(response_start_marker, 1)[1].strip()
    else:
        response_only = generated_text.strip()

    # Clean up any remaining instruction/response markers if they appear unexpectedly
    response_only = response_only.replace("### Instruction:", "").replace("### Response:", "").strip()
    print(f"Generated response from Telugu LLM: {response_only}")
    return response_only


# --- OCR Inference Function (Backend Logic) ---
def process_image_with_ocr(image_base64: str) -> str:
    """
    Decodes a base64 encoded image, processes it with the OCR model, and returns the extracted text.
    """
    try:
        # Decode the base64 string into raw bytes
        image_bytes = base64.b64decode(image_base64)
        # Open the image from bytes using Pillow (PIL) and convert to RGB format
        image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    except Exception as e:
        print(f"Error decoding image or opening with PIL: {e}")
        # Re-raise as a ValueError for better API error handling
        raise ValueError("Invalid image format or base64 string provided.")

    print("Image decoded and ready for OCR processing.")

    # Prepare the image for the OCR model using its specific processor
    # This generates pixel values and potentially input_ids needed by the model
    inputs = ocr_processor(images=image, return_tensors="pt").to(ocr_model.device)

    # Generate text from the image using the OCR model
    # max_new_tokens is increased to allow for longer OCR results
    generated_ids = ocr_model.generate(**inputs, max_new_tokens=500)

    # Decode the generated token IDs back into human-readable text
    extracted_text = ocr_processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
    print(f"Extracted text from image: {extracted_text}")
    return extracted_text


# --- API Endpoint for Telugu LLM (Existing) ---
@app.route('/generate', methods=['POST'])
def generate_text():
    """
    API endpoint to receive user text input and return Telugu LLM generated text.
    Expects a JSON payload with a 'text' key.
    """
    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400

    data = request.get_json()
    user_input = data.get('text')

    if not user_input:
        return jsonify({"error": "Missing 'text' in request body"}), 400

    try:
        llm_response = generate_telugu_response_backend(user_input)
        return jsonify({"response": llm_response})
    except Exception as e:
        print(f"Error during Telugu LLM generation: {e}")
        return jsonify({"error": "Internal server error during text generation"}), 500


# --- API Endpoint for OCR Model (New) ---
@app.route('/ocr_generate', methods=['POST'])
def ocr_generate_text():
    """
    API endpoint to receive a base64 encoded image and return extracted text using the OCR model.
    Expects a JSON payload with an 'image_base64' key, where the value is the base64 string of the image.
    """
    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400

    data = request.get_json()
    image_base64 = data.get('image_base64')

    if not image_base64:
        return jsonify({"error": "Missing 'image_base64' in request body"}), 400

    try:
        extracted_text = process_image_with_ocr(image_base64)
        return jsonify({"extracted_text": extracted_text})
    except ValueError as ve:
        # Handle specific errors related to image decoding/format
        return jsonify({"error": str(ve)}), 400
    except Exception as e:
        # Catch any other unexpected errors during OCR processing
        print(f"Error during OCR generation: {e}")
        return jsonify({"error": "Internal server error during OCR processing"}), 500


# --- Run the Flask App ---
if __name__ == '__main__':
    print("Starting Flask application...")
    # To run this, you might use: flask run
    # Or for development with automatic reload: flask --app backend_app run --debug
    # Or directly: python your_backend_file_name.py
    app.run(host='0.0.0.0', port=5000, debug=False)  # Set debug=True for development
